package java1.sorting.quickSort;

public class QuickSort {
}
