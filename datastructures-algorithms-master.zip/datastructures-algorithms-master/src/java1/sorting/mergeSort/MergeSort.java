package java1.sorting.mergeSort;

public class MergeSort {
}
